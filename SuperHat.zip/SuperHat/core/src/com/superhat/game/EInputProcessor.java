package com.superhat.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;

public class EInputProcessor  implements InputProcessor {
    SuperHat game;
    EInputProcessor(SuperHat game){
       this.game = game;
    }

    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        if(SX(screenX)<=400 ){
            game.vx-=3;
            game.sound2.play(0.1f);
        }
        if(SX(screenX)>=SX(game.width)-400 ){
            game.vx+=3;
            game.sound2.play(0.1f);
        }
        if(SY(screenY)<=400 ){
            game.vy-=3;
            game.sound2.play(0.1f);
        }
        if(SY(screenY)>=game.height*game.hph-400 ){
            game.vy+=3;
            game.sound2.play(0.1f);
        }
        return false;
    }
    public float SX(float x){
        return x*game.wpw;
    }
    public float SY(float y){
        return (Gdx.graphics.getHeight()-y)*game.wpw;
    }
    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {

        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
}
