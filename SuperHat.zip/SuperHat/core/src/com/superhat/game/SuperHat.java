package com.superhat.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ScreenUtils;

import java.awt.Point;
import java.util.Random;

import javax.xml.stream.events.EndElement;

public class SuperHat extends ApplicationAdapter {
	SpriteBatch batch;
	Random random;
	Texture img;
	Texture walls, floor, cat, bullet, aura, pat, button, hat;
	Texture[] enemyt = new Texture[5];
	TextureRegion[] enemy = new TextureRegion[5];
	TextureRegion cats, hats;
	Thread phys, lab;
	int l1 = 40, l2 = 40;
	int[][] mas = new int[l1][l2];
	int[][][] wall = new int[l1][l2][2];
	int r = 300;
	float[] bx  = new float[300];
	float[] by = new float[300];
	float[] bvx  = new float[300];
	float[] bvy = new float[300];
	float[] rx  = new float[300];
	float[] ry = new float[300];
	float[] rvx  = new float[300];
	float[] rvy = new float[300];
	float[] rh  = new float[1300];
	float[] rw  = new float[300];
	float[] rt  = new float[300];
	Sound sound1, sound2, sound3;
	int cx = 5, cy = 5, c = 0, m = l1*l2;
	int step = 100;
	float cumx = 0, cumy = 0;
	float cum = 3.25f;
	float x = 1000, y = 1000, vx = 0, vy = 0, ax = 0, ay = 0,  g = 0, w = 40, h = 40, res = 0.05f, rot = 0.0f;
	boolean end = false;
	boolean bs = false;
	int width, height;
	float hph, wpw;
	@Override
	public void create () {
		sound1 = Gdx.audio.newSound(Gdx.files.internal("sound1.m4a"));
		sound2= Gdx.audio.newSound(Gdx.files.internal("sound2.m4a"));
		sound3 = Gdx.audio.newSound(Gdx.files.internal("sound3.m4a"));
		random = new Random();
		batch = new SpriteBatch();
		walls = new Texture("wall.png");
		pat = new Texture("pat.png");
		cat = new Texture("cat.png");
		hat = new Texture("hat.png");
		enemyt[0]  = new Texture("r1.png");
		enemyt[1]  = new Texture("r2.png");
		enemyt[2]  = new Texture("r3.png");
		enemyt[3]  = new Texture("r4.png");
		enemyt[4]  = new Texture("r5.png");
		enemy[0] = new TextureRegion(enemyt[0]);
		enemy[1] = new TextureRegion(enemyt[1]);
		enemy[2] = new TextureRegion(enemyt[2]);
		enemy[3] = new TextureRegion(enemyt[3]);
		enemy[4] = new TextureRegion(enemyt[4]);
		cats = new TextureRegion(cat);
		hats = new TextureRegion(hat);
		floor = new Texture("floor.png");
		button = new Texture("button.png");
		width = Gdx.graphics.getWidth();
		height	= Gdx.graphics.getHeight();
		Gdx.app.log("ads", width+"");
		Gdx.app.log("ads", height+"");
		wpw = width/2195f;
		hph = height/1080f;
		phys = new Thread (){
			@Override
			public void run() {
				while(!end) {
					Sleep(10);
					vx += ax;
					vy += ay+g;
					x+=vx;
					y+=vy;
					for(int i=0;i<r;i++) {
						rx[i] += rvx[i];
						ry[i] += rvy[i];
						if(rvx[i]>0){
							rvx[i]-=res;
						}
						if(rvx[i]<0){
							rvx[i]+=res;
						}
						if(rvy[i]>0){
							rvy[i]-=res;
						}
						if(rvy[i]<0){
							rvy[i]+=res;
						}
						if(rvx[i]>-0.1f&&rvx[i]<0.1f){
							rvx[i] = 0;
						}
						if(rvy[i]>-0.1f&&rvy[i]<0.1f){
							rvy[i] = 0;
						}

						if(rvx[i]>8){
							rvx[i] = 8;
						}
						if(rvy[i]>8){
							rvy[i] = 8;
						}
						int px = (int)(rx[i]/step);
						int py = (int)(ry[i]/step);
						boolean ac = true;
						if(px<=1){
							px = l1-3;

						}
						if(px>=l1-2){
							px = 2;

						}
						if(py<=1){
							py = l2-3;

						}
						if(py>=l2-2){
							py = 2;
						}


						if (wall[px][py][0] == 1 && des(rx[i], px * step + step - 5, ry[i], py * step, rw[i], 10, rh[i], step)) {
							rvx[i] = -rvx[i] * 0.9f;
							rx[i] = px * step + step - 5 - rw[i] - 1;
						}
						if (wall[px - 1][py][0] == 1 && des(rx[i], px * step - 5, ry[i], py * step, rw[i], 10, rh[i], step)) {
							rvx[i] = -rvx[i] * 0.9f;
							rx[i] = px * step + 5 + 1;
						}
						if (wall[px][py + 1][1] == 1 && des(rx[i], px * step, ry[i], py * step + step - 5, rw[i], step, rh[i], 10)) {
							rvy[i] = -rvy[i] * 0.9f;
							ry[i] = py * step + step - 5 - rh[i] - 1;
						}
						if (wall[px][py][1] == 1 && des(rx[i], px * step,ry[i], py * step - 5, rw[i], step, rh[i], 10)) {
							rvy[i] = -rvy[i] * 0.9f;
							ry[i] = py * step + 5 + 1;

						}

						rot = (float)(vx);
						if(rx[i]<0||rx[i]>l1*step||ry[i]<0||ry[i]>l2*step){
							rx[i] = random.nextInt(l1)*step;
							ry[i] = random.nextInt(l2)*step;
							rw[i] = random.nextInt(40)+10;
							rh[i] = random.nextInt(40)+10;
							rvx[i] = 0;
							rvy[i] = 0;
							rt[i] = random.nextInt(5);
						}
					}
					if(vx>0){
						vx-=res;
					}
					if(vx<0){
						vx+=res;
					}
					if(vy>0){
						vy-=res;
					}
					if(vy<0){
						vy+=res;
					}
					if(vx>-0.1f&&vx<0.1f){
						vx = 0;
					}
					if(vy>-0.1f&&vy<0.1f){
						vy = 0;
					}

					if(vx>8){
						vx = 8;
					}
					if(vy>8){
						vy = 8;
					}
					int px = (int)(x/step);
					int py = (int)(y/step);
					boolean ac = true;
					if(px<=1){
						x = l1-3;

					}
					if(px>=l1-2){
						x = 3;

					}
					if(py<=1){
						y = l2-3;

					}
					if(py>=l2-2){
						y = 3;
					}


						if (wall[px][py][0] == 1 && des(x, px * step + step - 5, y, py * step, w, 10, h, step)) {
							vx = -vx * 0.9f;
							x = px * step + step - 5 - w - 1;
							sound3.play(0.2f);
						}
						if (wall[px - 1][py][0] == 1 && des(x, px * step - 5, y, py * step, w, 10, h, step)) {
							vx = -vx * 0.9f;
							x = px * step + 5 + 1;
							sound3.play(0.2f);
						}
						if (wall[px][py + 1][1] == 1 && des(x, px * step, y, py * step + step - 5, w, step, h, 10)) {
							vy = -vy * 0.9f;
							y = py * step + step - 5 - h - 1;
							sound3.play(0.2f);
						}
						if (wall[px][py][1] == 1 && des(x, px * step, y, py * step - 5, w, step, h, 10)) {
							vy = -vy * 0.9f;
							y = py * step + 5 + 1;
							sound3.play(0.2f);
						}
					for(int i=0;i<r;i++){
						if(des(x, rx[i], y, ry[i], w, rw[i], h, rh[i])){
							sound1.play();
							rx[i] = random.nextInt(l1)*step;
							ry[i] = random.nextInt(l2)*step;
							rw[i] = random.nextInt(20)+10;
							rh[i] = random.nextInt(20)+10;
							rvx[i] = 0;
							rvy[i] = 0;
							rt[i] = random.nextInt(5);
						}
					}
					rot = (float)(vx);
					if(x * cum - width * wpw / 2 >= 0 &&x * cum - width * wpw / 2<=l1*step) {
						cumx = x * cum - width * wpw / 2;
					}
					if(  y* cum - height * hph / 2<=l2*step&& y * cum - height * hph / 2>0 ) {
						cumy = y * cum - height * hph / 2;
					}
				}
			}
		};
		phys.start();
		Thread enemy = new Thread () {
			@Override
			public void run(){
				for(int i=0;i<r;i++){
					rx[i] = random.nextInt(l1)*step;
					ry[i] = random.nextInt(l2)*step;
					rw[i] = random.nextInt(20)+10;
					rh[i] = random.nextInt(20)+10;
					rvx[i] = 0;
					rvy[i] = 0;
					rt[i] = random.nextInt(5);
				}
				while(!end) {
					Sleep(500);
					for(int i=0;i<r;i++){
						rvx[i] +=  random.nextInt(6)+2;
						rvy[i] +=  random.nextInt(6)+2;



					}
				}
			}
		};
		enemy.start();
		lab = new Thread (){
			@Override
			public void run(){

				int mov = 0;
				while(c<m-1) {
					mov = random.nextInt(4) + 1;
					while (!check(mov)) {
						mov = random.nextInt(4) + 1;
					}
					if(bs) {
						if (mas[cx][cy]== 1) {
							cx++;
						}
						if (mas[cx][cy] == 2) {
							cy--;
						}
						if (mas[cx][cy] == 3) {
							cx--;
						}
						if (mas[cx][cy] == 4) {
							cy++;
						}
						bs = false;
					}else{
					if (mov == 1) {
						cx--;
					}
					if (mov == 2) {
						cy++;
					}
					if (mov == 3) {
						cx++;
					}
					if (mov == 4) {
						cy--;
					}
					if(cx>0&&mas[cx-1][cy]!=0&&mov!=3){
						wall[cx-1][cy][0] = 1;
					}
					if(cy<l2-1&&mas[cx][cy+1]!=0&&mov!=4){
						wall[cx][cy+1][1] = 1;
					}
					if(cx<l1-1&&mas[cx+1][cy]!=0&&mov!=1){
						wall[cx][cy][0] = 1;
					}
					if(cy>0&&mas[cx][cy-1]!=0&&mov!=2){
						wall[cx][cy][1] = 1;
					}
					mas[cx][cy] = mov;
					c++;
				}
				}
				for (int ix=0;ix<l1;ix++){
					for (int iy=0;iy<l2;iy++) {
						if(mas[ix][iy] == 0){
							mas[ix][iy] = 1;
						}
					}
					}
			}
		};
		lab.start();
		Gdx.input.setInputProcessor(new EInputProcessor(this));
	}
	boolean des(float x1, float x2, float y1, float y2, float w1, float w2,float h1,float h2  ){
		return (((x1 >= x2 && x1 <= x2 + w2) || (x1 <= x2 && x1 + w1 >= x2)) && ((y1 >= y2 && y1 <= y2 + h2) || (y1 <= y2 && y1 + h1 >= y2)));
	}
	boolean check(int mov){
		if((cx==0||mas[cx-1][cy]!=0)&&(cy==l2-1||mas[cx][cy+1]!=0)&&(cx==l1-1||mas[cx+1][cy]!=0)&&(cy==0||mas[cx][cy-1]!=0)){
			bs = true;
			return true;
		}
		if((mov==1&&(cx==0||mas[cx-1][cy]!=0))||(mov==2&&(cy==l2-1||mas[cx][cy+1]!=0))||(mov==3&&(cx==l1-1||mas[cx+1][cy]!=0))||(mov==4&&(cy==0||mas[cx][cy-1]!=0))){
			return false;
		}
		return true;
	}
	@Override
	public void render () {
		ScreenUtils.clear(1, 0, 0, 1);
		batch.begin();

		for (int ix=0;ix<l1;ix++){
			for (int iy=0;iy<l2;iy++){
				if(isView(ix, iy)) {
					if (mas[ix][iy] != 0) {
						drawcum(floor, step * ix-5, step * iy-5, step+10, step+10);
					}
					if (wall[ix][iy][0] == 1) {
						drawcum(walls, step * ix + step - 5 * (step / 20f), step * iy-4, 10 * (step / 20f), step+4);
					}
					if (wall[ix][iy][1] == 1) {
						drawcum(walls, step * ix - 5 * (step / 20f), step * iy - 2.5f * (step / 20f), step + 5 * (step / 20f), 5* (step / 20f));
					}
				}
			}
		}
		for(int i=0;i<r;i++) {
			drawcum(enemy[(int)rt[i]], rx[i], ry[i], rw[i], rh[i], -rot);
		}
		drawcum(pat, step * cx, step * cy, step, step);

		drawcum(cats, x, y, w, h, rot);
		drawcum(hats, x, y+15, w, h+Math.abs(vx+vy), rot);
		draw(button, 0, 0, 400, 400);
		batch.end();
	}
	boolean isView(int ix, int iy){
		float x1 = ix*step*cum;
		float x2 = cumx;
		float y1 = iy*step*cum;
		float y2 = cumy;
		float h1 = step*cum;
		float h2 = step*12;
		float w1 = step*cum;
		float w2 =step*23;

		return (((x1 >= x2 && x1 <= x2 + w2) || (x1 <= x2 && x1 + w1 >= x2)) && ((y1 >= y2 && y1 <= y2 + h2) || (y1 <= y2 && y1 + h1 >= y2)));
	}
	void drawcum(Texture texture, float x, float y, float width, float height){
		draw(texture, x*cum-cumx, y*cum-cumy, width*cum, height*cum);
	}
	void draw(Texture texture, float x, float y, float width, float height){
		batch.draw(texture, x*wpw, y*hph, width*wpw, height*hph);
	}
	void drawcum(TextureRegion texture, float x, float y, float width, float height, float rot){
		draw(texture, x*cum-cumx, y*cum-cumy, width*cum, height*cum, rot);
	}
	void draw(TextureRegion texture, float x, float y, float width, float height, float rot){
		batch.draw(texture, x*wpw, y*hph, width*wpw/2f, height*hph/2f, width*wpw, height*hph, 1, 1, rot);
	}
	void Sleep(int t){
		try{ Thread.sleep(t); }catch(Exception e){ }
	}
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
		walls.dispose();
		pat.dispose();
		floor.dispose();
		button.dispose();
		cat.dispose();
		hat.dispose();
	}
}
